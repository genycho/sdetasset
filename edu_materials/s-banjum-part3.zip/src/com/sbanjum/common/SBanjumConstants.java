package com.sbanjum.common;

/**
 * 각종 상수값 선언 
 *
 */
public class SBanjumConstants {
	private SBanjumConstants() {}
	
	/* 재료의 상태*/
	public static final String JAERYO_STATUS_ROTTEN = "상한상태";
	public static final String JAERYO_STATUS_INIT = "원재료상태";
	public static final String JAERYO_STATUS_SLICED = "썰은상태";
	public static final String JAERYO_STATUS_SOOTA = "수타면";
	public static final String JAERYO_STATUS_BOILED = "삶은상태";
	public static final String JAERYO_STATUS_FRIED = "볶은상태";
	
	public static final String JAERYO_STATUS_BAD = "잘못조리된상태";
	
	/* 야채 썰기 크기 */
	public static final String SIZE_LARGE = "크게썰기";
	public static final String SIZE_MEDIUM = "보통썰기";
	public static final String SIZE_SMALL = "작게썰기";
	
	/* 짜장면 맛 */
	public static final String TASTE_GOOD = "맛있다";
	public static final String TASTE_BAD = "맛없다";

	
	
	public static final String ROLE_MAINCHEF = "메인주방장";
	public static final String ROLE_SUBCHEF = "부주방장";
	public static final String ROLE_CHOBOCHEF = "초보주방장";
	
	public static final String ROLE_SAJANGNIM = "사장님";

}
