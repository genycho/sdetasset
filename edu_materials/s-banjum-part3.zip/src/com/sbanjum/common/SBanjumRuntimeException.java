package com.sbanjum.common;


/**
 * 잘못된 요리(법)에 대해 발생시키는 Exception 입니다
 *
 */
public class SBanjumRuntimeException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public SBanjumRuntimeException(String internalMessage, Throwable t) {
		super(internalMessage, t);
	}

	public SBanjumRuntimeException(String internalMessage) {
		super(internalMessage);
	}

	public SBanjumRuntimeException(Exception e2) {
		super(e2);
	}

}
