package com.sbanjum.common;


/**
 * 잘못된 주문에 대해 발생시키는 Exception 입니다
 *
 */
public class OrderException extends Exception {

	private static final long serialVersionUID = 2L;

	public OrderException(String internalMessage, Throwable t) {
		super(internalMessage, t);
	}

	public OrderException(String internalMessage) {
		super(internalMessage);
	}

	public OrderException(Exception e2) {
		super(e2);
	}

}
