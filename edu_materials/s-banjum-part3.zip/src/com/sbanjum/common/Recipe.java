package com.sbanjum.common;

/**
 * <pre> 
 * [S반점 요리점]
 * 1) 야채(호박 ¼개, 당근 ¼개, 양파 ½개) 를 중간 크기로 썬다 
 * 2) 썬 야채를 각각 볶는다. 당근과 호박은 2~3분, 양파는 1~2분 정도 센 불로 볶는다
 * 3) 춘장 15g을 2분 정도 볶는다.
 * 4) 돼지고기 20g을 2분 정도 센 불로 각각 볶는다 
 * 5) 미리 주문한 수타 면 200g을 5분 정도 삶는다 
 * 6) 야채, 춘장, 돼지고기를 같이 넣고 30초 정도 볶는다 
 * 7) 삶아진 면 위에 6)에서 볶은 것들을 얹어서 낸다 
 * 
 * ※ “곱배기”는 각 재료들을 정확히 2배로 해서 넣는다 
 * </pre>
 */
public class Recipe {
	public static double DANGEUN_AMOUNT = 1/4.;
	public static double DANGEUN_COOKTIME = 2.5;
	public static double YANGPA_AMOUNT = 1/2.;
	public static double YANGPA_COOKTIME = 1.5;
	public static double HOBAK_AMOUNT = 1/4.;
	public static double HOBAK_COOKTIME = 2.5;
	public static double MYUN_AMOUNT = 200.0;
	public static double MYUN_COOKTIME = 5.0;
	public static double GOGI_AMOUNT = 20.;
	public static double GOGI_COOKTIME = 2.0;
	public static double CHUNJANG_AMOUNT = 15.;
	public static double CHUNJANG_COOKTIME = 2.0;
}
