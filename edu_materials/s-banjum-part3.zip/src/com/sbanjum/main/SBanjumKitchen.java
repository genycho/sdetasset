package com.sbanjum.main;

import com.sbanjum.person.ChoboChef;
import com.sbanjum.person.MainChef;
import com.sbanjum.person.SubChef;

public class SBanjumKitchen {
	private ChoboChef choboChef;
	private SubChef subChef;
	private MainChef mainChef;
	
	private static SBanjumKitchen instance;
	
	private SBanjumKitchen(){}
	
	public static SBanjumKitchen get(){
		if(instance == null){
			instance = new SBanjumKitchen();
		}
		return instance;
	}

	public ChoboChef getChoboChef() {
		return choboChef;
	}

	public void setChoboChef(ChoboChef choboChef) {
		this.choboChef = choboChef;
	}

	public SubChef getSubChef() {
		return subChef;
	}

	public void setSubChef(SubChef subChef) {
		this.subChef = subChef;
	}

	public MainChef getMainChef() {
		return mainChef;
	}

	public void setMainChef(MainChef mainChef) {
		this.mainChef = mainChef;
	}

	
}
