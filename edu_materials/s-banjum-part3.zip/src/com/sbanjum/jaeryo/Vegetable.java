package com.sbanjum.jaeryo;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;

public abstract class Vegetable extends Jaeryo{

	protected String size = "";

	public Vegetable(String name) {
		super(name);
	}

	public void slice(String size){
		this.size = size;
		this.status = SBanjumConstants.JAERYO_STATUS_SLICED;
	}
}
