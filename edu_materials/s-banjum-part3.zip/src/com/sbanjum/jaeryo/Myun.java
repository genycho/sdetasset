package com.sbanjum.jaeryo;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;

/**
 * 재료 : 면
 *
 */
public class Myun extends Vegetable{
	
	public Myun() {
		super("면");
	}

	@Override
	public void cook(double minute) throws CookingException {
		if(minute <= 0){
			throw new CookingException("0분 이상을 조리해 주세요. ");
		}
		
		if(minute >=  4.5 && minute < 5.5){
			this.taste = SBanjumConstants.TASTE_GOOD;
		} else {
			this.taste = SBanjumConstants.TASTE_BAD;
		}
		this.status = SBanjumConstants.JAERYO_STATUS_BOILED;
	}

	
	public String toString(){
		return "면 입니다.";
	}
}
