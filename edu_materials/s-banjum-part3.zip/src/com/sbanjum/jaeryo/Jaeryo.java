package com.sbanjum.jaeryo;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;

/**
 * 재료들의 공통 속성을 갖는 추상 클래스 
 *
 */
public abstract class Jaeryo {
	protected String name;
	protected String status;
	protected String taste = SBanjumConstants.TASTE_GOOD;
	/** 몇인분용 재료 양인지 저장 */
	protected double amount;
	
	
	/** 생성자 */
	public Jaeryo(String name){
		this.status = SBanjumConstants.JAERYO_STATUS_INIT;
		this.name = name;
	}
	
	public void cut(double amount){
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getTaste() {
		return taste;
	}
	
	public void setTaste(String taste) {
		this.taste = taste;
	}

	/**
	 * TODO 재료를 설명하는 toString 메소드를 구현해야 한다
	 */
	public abstract String toString();

	public abstract void cook(double minute) throws CookingException;
		
}
