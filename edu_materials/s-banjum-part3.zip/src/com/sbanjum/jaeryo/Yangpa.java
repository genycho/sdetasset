package com.sbanjum.jaeryo;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;

/**
 * 재료 : 양파
 * 
 */
public class Yangpa extends Vegetable {

	public Yangpa(){
		super("양파");
	}

	@Override
	public void cook(double minute) throws CookingException {
		if (minute <= 0) {
			throw new CookingException("0분 이상을 조리해 주세요. ");
		}

		if (!SBanjumConstants.JAERYO_STATUS_SLICED.equals(this.status)) {
			throw new CookingException("재료가 아직 채썰기가 안 되어 있습니다");
		}

//		if (minute <= 1 && minute > 2) {//TODO 결함심기
		if (minute >= 1 && minute < 2) {
			this.taste = SBanjumConstants.TASTE_GOOD;
		} else {
			this.taste = SBanjumConstants.TASTE_BAD;
		}
		this.status = SBanjumConstants.JAERYO_STATUS_FRIED;
	}

	public String toString() {
		return "양파 입니다.";
	}
}
