package com.sbanjum.jaeryo;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.common.SBanjumRuntimeException;

/**
 * 재료 : 당근
 *
 */
public class DanGeun extends Vegetable{
	
	public DanGeun() {
		super("당근");
	}

	@Override
	public void cook(double minute) throws CookingException {
		if(minute <= 0){
			throw new CookingException("0분 이상을 조리해 주세요. ");
		}
		
		if(minute >10){
			throw new SBanjumRuntimeException("불이야!!");
		}
		
		if(!SBanjumConstants.JAERYO_STATUS_SLICED.equals(status)){
			throw new CookingException("재료가 아직 채썰기가 안 되어 있습니다");
		}
		
		if(this.size == SBanjumConstants.SIZE_LARGE || this.size == SBanjumConstants.SIZE_SMALL){
			throw new CookingException("이번에는 지원하지 않는 사이즈입니다");
		}else{
			if(minute >=  2 && minute < 3){
				this.taste = SBanjumConstants.TASTE_GOOD;
			} else {
				this.taste = SBanjumConstants.TASTE_BAD;
			}
			this.status = SBanjumConstants.JAERYO_STATUS_FRIED;
		}
	}
	
	public String toString(){
		return "당근 입니다.";
	}
}
