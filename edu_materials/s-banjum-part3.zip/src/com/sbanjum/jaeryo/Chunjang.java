package com.sbanjum.jaeryo;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;

/**
 * 재료 : 춘장
 * 
 */
public class Chunjang extends Jaeryo {

	public Chunjang() {
		super("춘장");
	}

	@Override
	public void cook(double minute) throws CookingException {
		if (minute <= 0) {
			throw new CookingException("0분 이상을 조리해 주세요. ");
		}

		if (minute >= 1.5 && minute < 2.5) {
			this.taste = SBanjumConstants.TASTE_GOOD;
		} else {
			this.taste = SBanjumConstants.TASTE_BAD;
		}
		this.status = SBanjumConstants.JAERYO_STATUS_FRIED;
	}

	public String toString() {
		return "춘장 입니다.";
	}
}
