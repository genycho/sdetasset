package com.sbanjum.serving;

/**
 * 손님 주문을 기록하는 클래스 입니다
 *
 */
public class Order {
	private int orderId;
	private int botongCount;
	private int goppagiCount;

	public Order(int orderId, int botongCount, int goppagiCount){
		this.orderId = orderId;
		this.botongCount = botongCount;
		this.goppagiCount = goppagiCount;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getBotongCount() {
		return botongCount;
	}

	public void setBotongCount(int botongCount) {
		this.botongCount = botongCount;
	}

	public int getGoppagiCount() {
		return goppagiCount;
	}

	public void setGoppagiCount(int goppagiCount) {
		this.goppagiCount = goppagiCount;
	}
}
