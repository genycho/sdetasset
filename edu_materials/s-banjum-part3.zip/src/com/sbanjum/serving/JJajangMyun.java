package com.sbanjum.serving;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.person.MainChef;

public class JJajangMyun {
	private String type;
	private String taste;
	private String amount = "안맞음";
	
	private static final Logger log = LoggerFactory
    .getLogger(JJajangMyun.class);
	
	/**
	 * 
	 * @param type
	 *            보통/곱배기
	 */
	public JJajangMyun(String type) {
		this.type = type;
	}

	public void cook(List<Jaeryo> ingredients, int inbun) {
		int tasteCode = 11 + 22 + 33 + 44 + 55 + 66;
		for (Jaeryo jaeryo : ingredients) {
			if ("당근".equals(jaeryo.getName())) {
				if ((jaeryo.getAmount() % 0.25) == 0
						&& SBanjumConstants.JAERYO_STATUS_FRIED.equals(jaeryo
								.getStatus())) {
					tasteCode = tasteCode - 11;
				}else{
					log.debug("당근 요리 잘못");
				}
			} else if ("호박".equals(jaeryo.getName())) {
				if ((jaeryo.getAmount() % 0.25) == 0
						&& SBanjumConstants.JAERYO_STATUS_FRIED.equals(jaeryo
								.getStatus())) {
					tasteCode = tasteCode - 22;
				}else{
					log.debug("호박 요리 잘못");
				}
			} else if ("양파".equals(jaeryo.getName())) {
				if ((jaeryo.getAmount() % 0.5) == 0
						&& SBanjumConstants.JAERYO_STATUS_FRIED.equals(jaeryo
								.getStatus())) {
					tasteCode = tasteCode - 33;
				}else{
					log.debug("양파 요리 잘못");
				}
			} else if ("면".equals(jaeryo.getName())) {
				if ((jaeryo.getAmount() % 200.) == 0
						&& SBanjumConstants.JAERYO_STATUS_BOILED.equals(jaeryo
								.getStatus())) {
					//TODO 결함심기, 실제 결함난곳. boiled가 아닌 Fried 체크해서 
					tasteCode = tasteCode - 44;
				}else{
					log.debug("면 요리 잘못");
				}
			} else if ("고기".equals(jaeryo.getName())) {
				if ((jaeryo.getAmount() % 20.) == 0
						&& SBanjumConstants.JAERYO_STATUS_FRIED.equals(jaeryo
								.getStatus())) {
					tasteCode = tasteCode - 55;
				}else{
					log.debug("고기 요리 잘못");
				}
			} else if ("춘장".equals(jaeryo.getName())) {
				if ((jaeryo.getAmount() % 15.) == 0
						&& SBanjumConstants.JAERYO_STATUS_FRIED.equals(jaeryo
								.getStatus())) {
					tasteCode = tasteCode - 66;
				}else{
					log.debug("춘장 요리 잘못");
				}
			} else {
				tasteCode = -1;
			}
			//TODO 결함심기, 실제 결함 난 곳
			log.debug("짜장면 맛 코드 = {}", tasteCode);
		}
		if(tasteCode == 0) {
			this.taste = SBanjumConstants.TASTE_GOOD;
		} else {
			log.info("짜장면 맛코드가 0이 아님.");
			this.taste = SBanjumConstants.TASTE_BAD;
		}
		
		if("보통".equals(this.type) && inbun ==1){
			this.amount = "맞음";
		}else if("곱배기".equals(this.type) && inbun ==2){
			this.amount = "맞음";
		}
	}
	
	public String getType() {
		return type;
	}

	public String getTaste() {
		return taste;
	}

	public String getAmount() {
		return amount;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("짜장면 종류는 ");
		sb.append(type);
		sb.append(" 이고, \t맛은 ");
		sb.append(taste);
		sb.append(" 입니다");
		return sb.toString();
	}

}
