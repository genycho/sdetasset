package com.sbanjum.person;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.OrderException;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.serving.JJajangMyun;
import com.sbanjum.serving.Order;

public class MainChef extends Chef {
	private static final Logger log = LoggerFactory
    .getLogger(MainChef.class);
	
	Map<Integer, Order> orderMap = new HashMap<Integer, Order>();
	Map<Integer, List<JJajangMyun>> foodMap = new HashMap<Integer, List<JJajangMyun>>();
	
	public MainChef(String role, String name, String salary) {
		super(role, name, salary);
	}

	public void order(Order order){
		
		if(orderMap.containsKey(order.getOrderId())){
			log.info("이미 주문받아서 요리 끝냈어.");
		}else{
			orderMap.put(order.getOrderId(), order);
			List<JJajangMyun> food;
			try {
				food = cook(order.getBotongCount(), order.getGoppagiCount());
				foodMap.put(order.getOrderId(), food);
			} catch (CookingException e) {
				log.error("요리가 잘못됐어. 뭘 잘못했지? {}다시 만들어야겠다", e.getMessage());
			}
		}
	}
	
	public List<JJajangMyun> done(int orderId) throws OrderException{
		if(foodMap.containsKey(orderId)){
			return foodMap.get(orderId);
		}else{
			log.info("주문ID = {}", orderId);
			throw new OrderException("아직 안 됐는데!!");
		}
	}
	
	public List<JJajangMyun> cook(int botongCount, int goppagiCount) throws CookingException {
		List<JJajangMyun> cookedFood = new ArrayList<JJajangMyun>();
		
		SubChef subChef = SBanjumKitchen.get().getSubChef();
		List<Jaeryo> ingredients = subChef.cook(botongCount + (goppagiCount *2));
		
		JJajangMyun imsi = null;
		for(int i=0; i<botongCount; i++){
			imsi = new JJajangMyun("보통");
			imsi.cook(ingredients, 1);
			cookedFood.add(imsi);
		}
		
		for(int i=0; i<goppagiCount; i++){
			imsi = new JJajangMyun("곱배기");
			imsi.cook(ingredients, 2);
			cookedFood.add(imsi);
		}

		return cookedFood;
	}		
}
