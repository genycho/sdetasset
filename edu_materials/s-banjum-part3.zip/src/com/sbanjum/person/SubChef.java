package com.sbanjum.person;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sbanjum.common.CookingException;
import com.sbanjum.jaeryo.Chunjang;
import com.sbanjum.jaeryo.Gogi;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.jaeryo.Myun;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.main.SBanjumKitchen;

public class SubChef extends Chef {
	private static final Logger log = LoggerFactory
    .getLogger(SubChef.class);
	
	public SubChef(String role, String name, String salary) {
		super(role, name, salary);
	}

	public List<Jaeryo> cook(int inbun) throws CookingException {
		if (inbun <= 0) {
			log.debug("0인분 이하로 요리를 요청하여 CookingException을 발생시킵니다");
			throw new CookingException("에이, 장난치지 마세요");
		}
		
		List<Jaeryo> ingredients = new ArrayList<Jaeryo>();
		ChoboChef choboChef = SBanjumKitchen.get().getChoboChef();
		List<Vegetable> bowl = choboChef.cook(inbun);
		//TODO (생각해보기)초보 주방장이 뭔가 물어보거나 이상이 있다고 했을 때 어떻게 대처해 줘야 할까?
		//예를 들면, "재료가 상했는데 어떻게 해야 해요?", "특정 재료가 다 떨어졌는데요?"와 같은. 
		//경우에 따라서는 부주방장도 해결해 줄 수 없을것이고, 이런 경우는 다시 상위로 그대로 전달하는 것도 정책이다.
		
		
		Vegetable vegetable = null;
		for(int i=0; i<bowl.size(); i++){
			vegetable = bowl.get(i);
			if("당근".equals(vegetable.getName())){
				vegetable.cook(2.5);
				ingredients.add(vegetable);
			}else if("호박".equals(vegetable.getName())){
				vegetable.cook(2.5);
				ingredients.add(vegetable);
			}else if("양파".equals(vegetable.getName())){
				vegetable.cook(1.5);
				ingredients.add(vegetable);
			}else{
				log.warn("초보 주방장!! 이 재료는 뭐야!!");
			}
			//TODO (생각해보기)초보 주방장이 맞는 재료를 맞게 썰었는지 확인해야 하지 않을까?
			//확인하지 않는 것도 의사결정이다. 대신 고민하고 검토하는게 필요.
		}
		
		ingredients.add(this.cookGogi(inbun));
		ingredients.add(this.cookChunjang(inbun));
		ingredients.add(this.cookMyun(inbun));

		return ingredients;
	}
	
	private Gogi cookGogi(double inbun) throws CookingException{
		Gogi gogi = new Gogi();
		gogi.cut(inbun*20);
		gogi.cook(2.0);
		return gogi;
	}
	
	private Chunjang cookChunjang(double inbun) throws CookingException{
		Chunjang chunjang = new Chunjang();
		chunjang.setAmount(inbun*20);//TODO	결함발생한 곳
		chunjang.cook(2.0);
		return chunjang;
	}

	private Myun cookMyun(double inbun) throws CookingException{
		Myun myun = new Myun();
//		myun.cut(inbun*20);	//TODO	결함발생한 곳
		
		myun.cut(inbun*200);
		myun.cook(5.0);
		return myun;
	}
}
