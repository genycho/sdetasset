package com.sbanjum.person;

/**
 * 사람에 대한 상위 클래스
 *
 */
public class Chef {
	private String role;
	private String name;
	private String salary;
	
	/** 생성자를 임의로 호출할 수 없음 */
	public Chef(String role, String name, String salary){
		this.role = role;
		this.name = name;
		this.salary = salary;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	public String toString(){
		StringBuffer sb = new StringBuffer();
		sb.append("제 이름은 ");
		sb.append(this.name);
		sb.append(", 저는 S반점에서 ");
		sb.append(this.role);
		sb.append(" 입니다.");
		sb.append("\n 제 월급은 ");
		sb.append(salary);
		sb.append(" 입니다.");
		
		return sb.toString();
	}
}
