package com.sbanjum.person;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.jaeryo.Yangpa;


/**
 *
 */
public class ChoboChef extends Chef{
	private static final Logger log = LoggerFactory
    .getLogger(ChoboChef.class);
	
	private DanGeun danGeun;
	private Hobak hobak;
	private Yangpa yangpa;
	
	public ChoboChef(String role, String name, String salary) {
		super(role, name, salary);
	}
	
	public List<Vegetable> cook(int inbun) throws CookingException{
		if(inbun <=0){
			log.debug("0이하로 재료 양을 요청하여 CookingException을 발생시킵니다 - {}인분",inbun);
			throw new CookingException("에이, 장난치지 마세요");
		}
		List<Vegetable> bowl = new ArrayList<Vegetable>();
		bowl.add(prepareDangeun(inbun));
		bowl.add(prepareHobak(inbun));
		bowl.add(prepareYangpa(inbun));
		
		return bowl;
	}
	
	private DanGeun prepareDangeun(int inbun){
		if(danGeun == null){
			danGeun = new DanGeun();
		}
		danGeun.cut(inbun * (1/4.));
		
		//TODO	야채 상태를 확인해야 하지 않을까? 

		danGeun.slice(SBanjumConstants.SIZE_MEDIUM);
		return danGeun;
	}

	private Hobak prepareHobak(int inbun){
		if(hobak == null){
			hobak = new Hobak();
		}
		hobak.cut(inbun * (1/4.));
		
		//TODO	야채 상태를 확인해야 하지 않을까? 

		hobak.slice(SBanjumConstants.SIZE_MEDIUM);
		return hobak;
	}
	
	private Yangpa prepareYangpa(int inbun){
		if(yangpa == null){
			yangpa = new Yangpa();
		}
		
		yangpa.cut(inbun * (1/2.));
		
		//TODO	야채 상태를 확인해야 하지 않을까? 

		yangpa.slice(SBanjumConstants.SIZE_MEDIUM);
		return yangpa;
	}

	//TODO	단위테스트를 쉽게 해 주는 setter 고려 
//	public void setDanGeun(DanGeun danGeun) {
//		this.danGeun = danGeun;
//	}
//
//	public void setHobak(Hobak hobak) {
//		this.hobak = hobak;
//	}
//
//	public void setYangpa(Yangpa yangpa) {
//		this.yangpa = yangpa;
//	}
}
