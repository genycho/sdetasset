package com.sbanjum.jaeryo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.common.SBanjumRuntimeException;
import com.sbanjum.jaeryo.DanGeun;

public class DanGeunTest {
	DanGeun danGeun;
	
	@Before
	public void setUp() throws Exception {
		danGeun = new DanGeun();
	}

	@After
	public void tearDown() throws Exception {
	}

	
	/**
	 * @Desc	기본 테스트	
	 * @Target	Dangeun
	 * @throws Exception
	 */
	@Test
	public void test_기본01() throws Exception {
		double amount = 1/4.0;
		double minutes = 2.5;
		String sliceSize = SBanjumConstants.SIZE_MEDIUM;
		
		danGeun.cut(amount);
		danGeun.slice(sliceSize);
		danGeun.cook(minutes);
		
		assertEquals("당근", danGeun.getName());
		assertEquals(0.25, danGeun.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED, danGeun.getStatus());
		assertEquals(SBanjumConstants.TASTE_GOOD, danGeun.getTaste());
		
		System.out.println(danGeun);
	}
	
	/**
	 * @Desc	너무 오래 요리했을 때의 테스트	
	 * @Target	Dangeun
	 * @throws Exception
	 */
	@Test
	public void test_너무익혔을때() throws Exception {
		double amount = 1/4.0;
		double minutes = 4;
		String sliceSize = SBanjumConstants.SIZE_MEDIUM;
		
		danGeun.cut(amount);
		danGeun.slice(sliceSize);
		danGeun.cook(minutes);
		
		assertEquals("당근", danGeun.getName());
		assertEquals(0.25, danGeun.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED, danGeun.getStatus());
		
		assertEquals(SBanjumConstants.TASTE_BAD, danGeun.getTaste());
	}
	
	/**
	 * @Desc	덜 볶았을 때의 테스트	
	 * @Target	Dangeun
	 * @throws Exception
	 */
	@Test
	public void test_덜볶았을때() throws Exception {
		double amount = 1/4.0;
		double minutes = 1.5;
		String sliceSize = SBanjumConstants.SIZE_MEDIUM;
		
		danGeun.cut(amount);
		danGeun.slice(sliceSize);
		danGeun.cook(minutes);
		
		assertEquals("당근", danGeun.getName());
		assertEquals(0.25, danGeun.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED, danGeun.getStatus());
		
		assertEquals(SBanjumConstants.TASTE_BAD, danGeun.getTaste());
	}
	
	/**
	 * @Desc	10분 이상으로 오래 태웠을 때의 테스트	
	 * @Target	Dangeun
	 * @throws Exception
	 */
	@Test(expected=SBanjumRuntimeException.class)
	public void test_태웠을때() throws Exception {
		double amount = 1/4.0;
		double minutes = 11.;
		String sliceSize = SBanjumConstants.SIZE_MEDIUM;
		
		danGeun.cut(amount);
		danGeun.slice(sliceSize);
		danGeun.cook(minutes);
		
		fail("기대한 Exception이 발생하지 않았습니다");
		
	}

	/**
	 * @Desc	당근을 5/3개로 요리했을 때	
	 * @Target	Dangeun
	 * @Expected	양을 5/3개로 잘 볶아진다
	 * @throws Exception
	 */
	@Test
	public void test_당근양에대한테스트() throws Exception {
		double amount = 5/3.0;
		double minutes = 2.5;
		String sliceSize = SBanjumConstants.SIZE_MEDIUM;
		
		danGeun.cut(amount);
		danGeun.slice(sliceSize);
		danGeun.cook(minutes);
		
		assertEquals("당근", danGeun.getName());
		assertEquals(amount, danGeun.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED, danGeun.getStatus());
		assertEquals(SBanjumConstants.TASTE_GOOD, danGeun.getTaste());
	}
	
	/**
	 * @Desc	썰기크기에대한테스트	
	 * @Target	Dangeun
	 * @throws Exception
	 */
	@Test
	public void test_썰기크기에대한테스트() throws Exception {
		double amount = 1/4.0;
		double minutes = 2.5;
		String sliceSize = SBanjumConstants.SIZE_LARGE;
		
		danGeun.cut(amount);
		danGeun.slice(sliceSize);
		try{
			danGeun.cook(minutes);
			fail("기대한 Exception이 발생하지 않았습니다.");
		}catch(CookingException expected){
			assertEquals("이번에는 지원하지 않는 사이즈입니다", expected.getMessage());
		}
	}
	
	/**
	 * @Desc	썰지않고바로요리했을때	
	 * @Target	Dangeun
	 * @throws Exception
	 */
	@Test(expected = CookingException.class)
	public void test_썰지않고바로요리했을때() throws Exception {
		double amount = 1/4.0;
		double minutes = 2.5;
		
		danGeun.cut(amount);
//		danGeun.slice(sliceSize);
		danGeun.cook(minutes);
		
		fail("기대한 Exception이 발생하지 않았습니다.");
		
	}
	
	@Test(expected = CookingException.class)
	public void test_0분으로요리테스트() throws Exception {
		double amount = 1/4.0;
		double minutes = 0;
		String sliceSize = SBanjumConstants.SIZE_MEDIUM;
		
		danGeun.cut(amount);
		danGeun.slice(sliceSize);
		danGeun.cook(minutes);
		
		fail("기대한 Exception이 발생하지 않았습니다.");
		
	}
	
	@Test
	public void test_썰기크기에대한추가테스트() throws Exception {
		double amount = 1/4.0;
		double minutes = 2.5;
		String sliceSize = SBanjumConstants.SIZE_SMALL;
		
		danGeun.cut(amount);
		danGeun.slice(sliceSize);
		try{
			danGeun.cook(minutes);
			fail("기대한 Exception이 발생하지 않았습니다.");
		}catch(CookingException expected){
			assertEquals("이번에는 지원하지 않는 사이즈입니다", expected.getMessage());
		}
	}
	
}
