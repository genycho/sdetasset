package com.sbanjum.features.step_definitions;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

import java.util.List;

import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.person.ChoboChef;
import com.sbanjum.person.MainChef;
import com.sbanjum.person.SubChef;
import com.sbanjum.serving.JJajangMyun;
import com.sbanjum.serving.Order;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class OrderSteps {
	
	SBanjumKitchen kitchen;
	MainChef mainChef;
	List<JJajangMyun> resultList;
	int orderId = 0;
	
	@Before
	private void setUp(){
		mainChef = new MainChef(SBanjumConstants.ROLE_MAINCHEF, "이연복", "오백만원");
		SBanjumKitchen.get().setMainChef(mainChef);
		SBanjumKitchen.get().setSubChef(new SubChef(SBanjumConstants.ROLE_SUBCHEF, "샘킴", "삼백만원"));
		SBanjumKitchen.get().setChoboChef(new ChoboChef(SBanjumConstants.ROLE_CHOBOCHEF, "김풍", "백만원"));
	}
	
	@Given("^주문해 주세요$")
	public void 주문해_주세요() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//준비~
		setUp();
		orderId++;
	}

	@When("^보통 (\\d+)개, 곱배기 (\\d+)개 주세요$")
	public void 보통_개_곱배기_개_주세요(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Order order = new Order(orderId, arg1, arg2);
		mainChef.order(order);
		System.out.println("실행되고 있습니다. ");
	}
	
	@Then("^짜장면 보통 (\\d+)개, 곱배기 (\\d+)개가 만들어진다$")
	public void 짜장면_보통_개_곱배기_개가_만들어진다(int arg1, int arg2) throws Throwable {
	
		this.resultList = mainChef.done(orderId);
		int botongCount = 0;
		int goppagiCount = 0;
		
		assertThat(resultList.size(), is(arg1+arg2));
		for(int i=0; i<resultList.size();i++){
			if("보통".equals(resultList.get(i).getType())){
				botongCount++;
			}else if("곱배기".equals(resultList.get(i).getType())){
				goppagiCount++;
			}else{
				fail("예상하지 않은 짜장면 종류입니다 - " + resultList.get(i).getType());
			}
		}
		assertThat(botongCount, is(arg1));
		assertThat(goppagiCount, is(arg2));
	}

	@Then("^각 짜장면의 맛은 \"([^\"]*)\", 양은 \"([^\"]*)\" 이다$")
	public void 각_짜장면의_맛은_양은_이다(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		for(int i=0; i<resultList.size();i++){
			
			assertThat(resultList.get(i).getTaste(), is(arg1));
			assertThat(resultList.get(i).getAmount(), is(arg2));
		}
	}
}
