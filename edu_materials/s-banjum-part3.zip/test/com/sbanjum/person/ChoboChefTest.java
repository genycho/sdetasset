package com.sbanjum.person;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.person.ChoboChef;

public class ChoboChefTest {
	ChoboChef choboChef;
	
	@Before
	public void setUp() throws Exception {
		choboChef = new ChoboChef(SBanjumConstants.ROLE_CHOBOCHEF, "테스트용", "백만원");
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * @Desc	기본적인 테스트
	 * @Input	3인분 준비
	 * @Expected	당근, 호박, 양파가 각각 3인분씩(3/4개, 3/4개, 3/2개) 준비된다
	 */
	@Test
	public void test_기본테스트() throws Exception {
		int inbun = 3;
		List<Vegetable> resultList = choboChef.cook(inbun);
		
		assertNotNull(resultList);
		assertEquals(3, resultList.size());
		
		DanGeun danGeun = null;
		Hobak hobak = null;
		Yangpa yangpa = null;
		
		for(int i=0; i<resultList.size(); i++){
			if("당근".equals(resultList.get(i).getName())){
				danGeun = (DanGeun) resultList.get(i);
			}else if("호박".equals(resultList.get(i).getName())){
				hobak = (Hobak) resultList.get(i);
			}else if("양파".equals(resultList.get(i).getName())){
				yangpa = (Yangpa) resultList.get(i);
			} 
		}
		
		assertNotNull(danGeun);
		assertEquals(0.25*inbun, danGeun.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_SLICED, danGeun.getStatus());

		assertNotNull(hobak);
		assertEquals(0.25*inbun, hobak.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_SLICED, hobak.getStatus());

		assertNotNull(yangpa);
		assertEquals(0.5*inbun, yangpa.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_SLICED, yangpa.getStatus());
	}

	@Test(expected=CookingException.class)
	public void test_예외확인테스트() throws Exception {
		int inbun = 0;
		
		choboChef.cook(inbun);
		
		fail("기대한 Exception이 발생하지 않았습니다");
	}
	
	
	@Ignore	//상한 재료 상황을 만들수가 없어서 테스트 보류?
	public void test_상한재료에대한테스트() throws Exception {
		int inbun = 2;
		choboChef.cook(inbun);
	}
}
