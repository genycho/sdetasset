package com.sbanjum.person;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.Chunjang;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Gogi;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.jaeryo.Myun;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.person.ChoboChef;
import com.sbanjum.person.MainChef;
import com.sbanjum.person.SubChef;
import com.sbanjum.serving.JJajangMyun;
import com.sbanjum.serving.Order;

@RunWith(MockitoJUnitRunner.class)
public class MainChefTDDTest {
	MainChef mainChef;

	SubChef subChef;
	ChoboChef choboChef;

	@Before
	public void setUp() throws Exception {
		mainChef = new MainChef(SBanjumConstants.ROLE_MAINCHEF, "테스트용", "오백만원");
		subChef = mock(SubChef.class);
		choboChef = mock(ChoboChef.class);
		SBanjumKitchen.get().setChoboChef(choboChef);
		SBanjumKitchen.get().setSubChef(subChef);
	}


	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCook_기본테스트() throws Exception {
		int botongCount = 1;
		int goppagiCount = 1;
		
	}
	
}
