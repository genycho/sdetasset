package com.sbanjum.person.design;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.Chunjang;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Gogi;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.jaeryo.Myun;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.person.ChoboChef;
import com.sbanjum.person.SubChef;

public class SubChefTest {
	SubChef subChef;

	@Before
	public void setUp() throws Exception {
		subChef = new SubChef(SBanjumConstants.ROLE_SUBCHEF, "테스트용", "삼백만원");
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * @Desc 기본적인 테스트
	 * @Input 3인분 준비
	 * @Expected 당근, 호박, 양파, 춘장, 고기, 면이 각각 3인분씩(3/4개, 3/4개, 3/2개, 45g, 60g,
	 *           600g) 이 볶거나 삶아진 상태로 준비된다
	 */
	@Test
	public void test_기본테스트() throws Exception {
		int inbun =3;
		fail("Not yet implemented");
	}

	/**
	 * @Desc 잘못된 야채 준비 체크 테스트1
	 * @Input 상세 정의 필요 - 다른 야채를 준비, 야채 양이 안 맞을 때 
	 * @Expected 어떻게 해야 할까?
	 */
	@Test
	public void test_초보주방장이재료를잘못준비했을때() throws Exception {
		fail("Not yet implemented");
	}
	
	/**
	 * @Desc 잘못된 야채 준비 체크 테스트2
	 * @Input 상세 정의 필요 - 야채 양이 안 맞을 때 
	 * @Expected 어떻게 해야 할까?
	 */
	@Test
	public void test_초보주방장이재료양을잘못준비했을때() throws Exception {
		fail("Not yet implemented");
	}

	/**
	 * @Desc 잘못된 야채 준비 체크 테스트3
	 * @Input 상세 정의 필요 - 야채 양이 안 맞을 때 
	 * @Expected 어떻게 해야 할까?
	 */

	@Test
	public void test_초보주방장이안썰었을때테스트() throws Exception {
		fail("Not yet implemented");
	}

	
	/**
	 * @Desc 잘못된 양을 요청했을 때
	 * @Input 0인분 준비
	 * @Expected 에러가 발생한다. CookingException이 적합할까? 
	 */
	@Test(expected=CookingException.class)
	public void test_잘못된양을요청할때() throws Exception {
		int inbun =0;
		fail("Not yet implemented");
	}

}
