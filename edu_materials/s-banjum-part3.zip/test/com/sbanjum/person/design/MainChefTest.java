package com.sbanjum.person.design;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.Chunjang;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Gogi;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.jaeryo.Myun;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.person.ChoboChef;
import com.sbanjum.person.MainChef;
import com.sbanjum.person.SubChef;
import com.sbanjum.serving.JJajangMyun;

@RunWith(MockitoJUnitRunner.class)
public class MainChefTest {
	MainChef mainChef;

	@Before
	public void setUp() throws Exception {
		mainChef = new MainChef(SBanjumConstants.ROLE_MAINCHEF, "테스트용", "오백만원");
	}


	@After
	public void tearDown() throws Exception {
	}

	/**
	 * @Desc 기본적인 테스트1
	 * @Input 보통1개, 곱배기 1개
	 * @Expected 짜장면 보통 1개, 곱배기 1개가 맛있는 상태로 만들어 진다
	 */
	@Test
	public void testCook_기본테스트1() throws Exception {
		int botongCount = 1;
		int goppagiCount = 1;
		
		fail("Not yet implemented");
	}
	
	/**
	 * @Desc 기본적인 테스트2
	 * @Input 보통3개, 곱배기0개
	 * @Expected 짜장면 보통3개, 곱배기 0개가 맛있는 상태로 만들어 진다
	 */
	@Test
	public void testCook_기본테스트2() throws Exception {
		int botongCount = 3;
		int goppagiCount = 0;
		
		fail("Not yet implemented");
	}
	
	/**
	 * @Desc 기본적인 테스트2
	 * @Input 보통0개, 곱배기2개
	 * @Expected 짜장면 보통01개, 곱배기 2개가 맛있는 상태로 만들어 진다
	 */
	@Test
	public void testCook_기본테스트3() throws Exception {
		int botongCount = 0;
		int goppagiCount = 2;
		
		fail("Not yet implemented");
	}
	
	
	
	/**
	 * @Desc 부주방장이 준비한 재료 양이 맞지 않았을 때
	 * @Input 보통1개, 곱배기 1개
	 * @Expected 어떻게 해야 할까? 
	 */
	@Test(expected=CookingException.class)
	public void testCook_재료양이안맞을때() throws Exception {
		int botongCount = 1;
		int goppagiCount = 1;
		
		fail("Not yet implemented");
	}

	/**
	 * @Desc 부주방장이 준비한 재료가 볶거나삶아지지 않았을 때
	 * @Input 보통1개, 곱배기 1개
	 * @Expected 어떻게 해야 할까? 
	 */
	@Test(expected=CookingException.class)
	public void testCook_재료를볶지않았을때() throws Exception {
		int botongCount = 1;
		int goppagiCount = 1;
		
		fail("Not yet implemented");
	}
	
	/**
	 * @Desc 부주방장이 준비한 재료에 빠진게 있을 때
	 * @Input 보통1개, 곱배기 1개
	 * @Expected 어떻게 해야 할까? 
	 */
	@Test(expected=CookingException.class)
	public void testCook_필수재료가빠졌을때() throws Exception {
		int botongCount = 1;
		int goppagiCount = 1;
		
		fail("Not yet implemented");
	}
}
