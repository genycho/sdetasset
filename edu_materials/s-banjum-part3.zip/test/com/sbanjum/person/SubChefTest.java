package com.sbanjum.person;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.person.ChoboChef;
import com.sbanjum.person.SubChef;

public class SubChefTest {
	SubChef subChef;
	ChoboChef choboChef;
	
	@Before
	public void setUp() throws Exception { 
		subChef = new SubChef(SBanjumConstants.ROLE_SUBCHEF, "테스트용", "삼백만원");
		choboChef = new ChoboChef(SBanjumConstants.ROLE_CHOBOCHEF, "테스트용", "백만원");
		SBanjumKitchen.get().setChoboChef(choboChef);
		
		//TODO	(생각하기) 진정한 '단위테스트'에 대한 논란이되는 부분. 지금 테스트하려는 건 SubChef인데
		//이미 ChoboChef가 개발이 다 되었다고 가정하고 이를 활용하는 테스트는 단위테스트일까? 
		//단위테스트의 정의상으로는 위배된다. 하지만 내가 작성한 SubChef 개발 코드와 테스트 코드(케이스)가 
		//choboChef의 결과에 따라 굉장히 다른 로직을 타고 결과를 내는가를 살펴보자. 
		//또한 이미 ChoboChef 개발이 완료되었는지 완료되지 않았는지 등 ROI를 고민해 볼 필요가 있다.
		//더더욱 중요한 건 어찌됐든 개발 완료된 ChoboChef와 SubChef를 연결해서 테스트하는 건 반드시 필요하다는 
		//점이다. 이 SubChefTest와 또하나 추가된 SubChefMockitoTest를 보고 고민해 보자.  
	}

	@After
	public void tearDown() throws Exception {
	}

	
	@Test
	public void test_기본테스트() throws Exception {
		int inbun = 3;
		
		List<Jaeryo> resultList = subChef.cook(inbun);
		
		assertNotNull(resultList);
		assertEquals(6,resultList.size());
		
		Jaeryo jaeryo = null;
		for(int i=0; i<resultList.size(); i++){
			if("당근".equals(resultList.get(i).getName())){
				jaeryo = (DanGeun) resultList.get(i);
				
				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED , jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD , jaeryo.getTaste());
			}else if("호박".equals(resultList.get(i).getName())){
				jaeryo = (Hobak) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED , jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD , jaeryo.getTaste());
			}else if("양파".equals(resultList.get(i).getName())){
				jaeryo = (Yangpa) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED , jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD , jaeryo.getTaste());
			}else if("면".equals(resultList.get(i).getName())){
				jaeryo = (Yangpa) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_BOILED, jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD , jaeryo.getTaste());
			}else if("춘장".equals(resultList.get(i).getName())){
				jaeryo = (Yangpa) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED , jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD , jaeryo.getTaste());
			}else if("고기".equals(resultList.get(i).getName())){
				jaeryo = (Yangpa) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED , jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD , jaeryo.getTaste());
			}else{
				fail("이상한 재료를 요리했습니다 - "+jaeryo.getName());
			}
		}
		//TODO	(생각하기)만약 메인주방장이 매번 요리를 할 때마다 부주방장이 각 재료들을 알맞은 양으로, 
		// 맛있게 볶았는지를 확인할 수도 있습니다. 또는 시간이 없기 때문에 양만 확인하고 잘 볶았는지는
		// 확인 안 할 수도 있습니다. 실제로도 통합된 개발코드 상에서 모든 예외적인 상황을 다 확인할 수 없습니다.
		// 상세한 검증을 수행하는 단위테스트가 작성되어 있고, 이 단위테스트가 수시로 검증을 수행한다면 
		// 이런 위험성은 크게 줄일 수 있습니다. 
	}
	
	
	@Test
	public void test_잘못된양요청테스트() throws Exception {
		int inbun = 0;
		
		try{
			subChef.cook(inbun);
			fail("기대한 Exception이 발생하지 않았습니다");
		}catch(CookingException expectedEx){
			assertEquals("에이, 장난치지 마세요", expectedEx.getMessage());
		}
	}
	
	@Test
	public void test_굉장히많은양요청테스트() throws Exception {
		int inbun = 1000;
		
		List<Jaeryo> resultList = subChef.cook(inbun);
		
		assertNotNull(resultList);
		assertEquals(6,resultList.size());
		
	}
	
}
