package com.sbanjum.person;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.Chunjang;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Gogi;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.jaeryo.Myun;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.person.MainChef;
import com.sbanjum.person.SubChef;
import com.sbanjum.serving.JJajangMyun;
import com.sbanjum.serving.Order;

@RunWith(MockitoJUnitRunner.class)
public class MainChefMockitoTest {
	/** 다른 재료를 준비했을 때 */
	private static final int TESTMODE_WRONGNAME = -2;
	/** 특정 재료가 누락되었을 때 */
	private static final int TESTMODE_WRONGCOUNT = -3;
	/** 볶거나 요리되지 않은 상태 재료일 때 */
	private static final int TESTMODE_WRONGSTATUS = -4;
	/** 재료가 맛이 없을 때 */
	private static final int TESTMODE_BADTASTE = -5;
	private static int TESTMODE_NORMAL = 1;
	private static int TESTMODE_NULL = -1;

	MainChef mainChef;
	SubChef subChef;

	@Before
	public void setUp() throws Exception {
		mainChef = new MainChef(SBanjumConstants.ROLE_MAINCHEF, "테스트용", "오백만원");
		subChef = mock(SubChef.class);
		SBanjumKitchen.get().setSubChef(subChef);
	}


	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCook_기본테스트() throws Exception {
		int botongCount = 1;
		int goppagiCount = 1;
		
		int tempInbut = botongCount + goppagiCount*2;
		when(subChef.cook(tempInbut)).thenReturn(this.mockPrepare(tempInbut, TESTMODE_NORMAL));
		
		List<JJajangMyun> resultList = mainChef.cook(botongCount, goppagiCount);

		assertNotNull(resultList);
		assertEquals(2, resultList.size());

		int botongCheck = 0;
		int goppagiCheck = 0;

		for (JJajangMyun temp : resultList) {
			if ("보통".equals(temp.getType())) {
				botongCheck++;
			} else if ("곱배기".equals(temp.getType())) {
				goppagiCheck++;
			} else {
				fail("잘못된 짜장면 종류입니다");
			}
			assertEquals("맞음", temp.getAmount());
			assertEquals(SBanjumConstants.TASTE_GOOD, temp.getTaste());
		}
		assertEquals(botongCount, botongCheck);
		assertEquals(goppagiCount, goppagiCheck);

		// TODO (생각하기)테스트 코드 외에도 결함의 원인을 쉽게 찾고 고칠 수 있게 지원해 주는 도구
		// (1) 로그처리하기 - logback.xml 파일의 로그 수준을 debug로 낮춘 후에 결함의 원인을 쉽게 찾기
		// (2) 에러코드(맛코드)와 같이 오류의 원인을 직관적으로 파악할 수 있는 수단을 설계 단계부터 도입하기
	}
	
	@Test
	public void testCook_재료양이안맞을때() throws Exception {
		int botongCount = 1;
		int goppagiCount = 1;
		
		int tempInbut = 2;//3인분 양이 아닌 2인분 양으로 준비  
		
		when(subChef.cook(tempInbut)).thenReturn(this.mockPrepare(tempInbut, TESTMODE_NORMAL));
		
		List<JJajangMyun> resultList = mainChef.cook(botongCount, goppagiCount);
		
		//TODO	(생각하기) 현재의 개발코드는 부주방장이 양이 안맞거나 잘못 요리한 것에 대한 체크는 수행하지 않는다.
		//개발단계 분석,설계부터 이런 요건들에 대해 논의를 하고 로직을 정할 필요가 있다.
		fail("처리로직 생각해 보기");
	}
	
	@Ignore
	public void testCook_재료를볶지않았을때() throws Exception {
		
	}
	
	@Ignore
	public void testCook_필수재료가빠졌을때() throws Exception {
	
	}

	private List<Jaeryo> mockPrepare(int inbun, int testMode) {
		List<Jaeryo> tempList = new ArrayList<Jaeryo>();

		Jaeryo temp = null;
		if (testMode == TESTMODE_NORMAL) {
			temp = new DanGeun();
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 호박 임의 더하기 */
			temp = new Hobak();
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 양파 임의 더하기 */
			temp = new Yangpa();
			temp.setAmount(inbun * 1 / 2.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 춘장 */
			temp = new Chunjang();
			temp.setAmount(inbun * 15);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 고기 */
			temp = new Gogi();
			temp.setAmount(inbun * 20);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 면 */
			temp = new Myun();
			temp.setAmount(inbun * 200);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_BOILED);
			tempList.add(temp);
		} else if (testMode == TESTMODE_NULL) {
			tempList = null;
		} else if (testMode == TESTMODE_WRONGCOUNT) {
			temp = new DanGeun();
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 호박 임의 더하기 */
			temp = new Hobak();
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			tempList.add(temp);
		} else if (testMode == TESTMODE_WRONGNAME) {
			temp = new DanGeun();
			temp.setName("Carrot");
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 호박 임의 더하기 */
			temp = new Hobak();
			temp.setName("Pumpkin");
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 양파 임의 더하기 */
			temp = new Yangpa();
			temp.setName("Onion");
			temp.setAmount(inbun * 1 / 2.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 춘장 */
			temp = new Chunjang();
			temp.setName("ChineseSauce");
			temp.setAmount(inbun * 15);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 고기 */
			temp = new Gogi();
			temp.setName("Meat");
			temp.setAmount(inbun * 20);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			tempList.add(temp);
			/* 면 */
			temp = new Myun();
			temp.setName("Noodles");
			temp.setAmount(inbun * 200);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_BOILED);
			tempList.add(temp);
		} else if (testMode == TESTMODE_WRONGSTATUS) {
			temp = new DanGeun();
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			tempList.add(temp);
			/* 호박 임의 더하기 */
			temp = new Hobak();
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			tempList.add(temp);
			/* 양파 임의 더하기 */
			temp = new Yangpa();
			temp.setAmount(inbun * 1 / 2.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			tempList.add(temp);
			/* 춘장 */
			temp = new Chunjang();
			temp.setAmount(inbun * 15);//TODO	테스트코드의 작성실수,실제 춘장,고기를 20,15g로 작성
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_INIT);
			tempList.add(temp);
			/* 고기 */
			temp = new Gogi();
			temp.setAmount(inbun * 20);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_INIT);
			tempList.add(temp);
			/* 면 */
			temp = new Myun();
			temp.setAmount(inbun * 200);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_INIT);
			tempList.add(temp);
		} else if (testMode == TESTMODE_BADTASTE) {
			temp = new DanGeun();
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			temp.setTaste(SBanjumConstants.TASTE_BAD);
			tempList.add(temp);
			/* 호박 임의 더하기 */
			temp = new Hobak();
			temp.setAmount(inbun * 1 / 4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			temp.setTaste(SBanjumConstants.TASTE_BAD);
			tempList.add(temp);
			/* 양파 임의 더하기 */
			temp = new Yangpa();
			temp.setAmount(inbun * 1 / 2.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			temp.setTaste(SBanjumConstants.TASTE_BAD);
			tempList.add(temp);
			/* 춘장 */
			temp = new Chunjang();
			temp.setAmount(inbun * 15);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			temp.setTaste(SBanjumConstants.TASTE_BAD);
			tempList.add(temp);
			/* 고기 */
			temp = new Gogi();
			temp.setAmount(inbun * 20);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			temp.setTaste(SBanjumConstants.TASTE_BAD);
			tempList.add(temp);
			/* 면 */
			temp = new Myun();
			temp.setAmount(inbun * 200);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_BOILED);
			temp.setTaste(SBanjumConstants.TASTE_BAD);
			tempList.add(temp);
		} else {
			System.out.println("Not checking test mode. " + testMode);
		}
		return tempList;
	}
}
