package com.sbanjum.person;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.person.ChoboChef;
import com.sbanjum.person.MainChef;
import com.sbanjum.person.SubChef;
import com.sbanjum.serving.JJajangMyun;
import com.sbanjum.serving.Order;

public class MainChefTest {
	MainChef mainChef;
	
	SubChef subChef;
	ChoboChef choboChef;
	
	@Before
	public void setUp() throws Exception { 
		mainChef = new MainChef(SBanjumConstants.ROLE_MAINCHEF, "테스트용", "오백만원");
		subChef = new SubChef(SBanjumConstants.ROLE_SUBCHEF, "테스트용", "삼백만원");
		choboChef = new ChoboChef(SBanjumConstants.ROLE_CHOBOCHEF, "테스트용", "백만원");
		SBanjumKitchen.get().setChoboChef(choboChef);
		SBanjumKitchen.get().setSubChef(subChef);
		
		//TODO	(생각하기) MainChef 레벨에서의 통합 테스트와 단위테스트   
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testWorkflow_기본흐름테스트() throws Exception {
		int orderId =1;
		int botongCount = 1;
		int goppagiCount =1;
		Order order = new Order(orderId, botongCount, goppagiCount);
		
		mainChef.order(order);
		
		List<JJajangMyun> resultList = mainChef.done(orderId);
		
	}
	
	
	@Test
	public void testCook_기본테스트() throws Exception {
		int botongCount =1;
		int goppagiCount = 1;
		
		List<JJajangMyun> resultList = mainChef.cook(botongCount, goppagiCount);
		
		assertNotNull(resultList);
		assertEquals(2,resultList.size());

		int botongCheck = 0;
		int goppagiCheck = 0;
		
		for(JJajangMyun temp : resultList){
			if("보통".equals(temp.getType())){
				botongCheck ++;
			}else if("곱배기".equals(temp.getType())){
				goppagiCheck ++;
			}else{
				fail("잘못된 짜장면 종류입니다");
			}
			assertEquals("맞음" , temp.getAmount());
			assertEquals(SBanjumConstants.TASTE_GOOD , temp.getTaste());
		}
		assertEquals(botongCount, botongCheck);
		assertEquals(goppagiCount, goppagiCheck); 
		
		//TODO	(생각하기)테스트 코드 외에도 결함의 원인을 쉽게 찾고 고칠 수 있게 지원해 주는 도구
		//(1) 로그처리하기 - logback.xml 파일의 로그 수준을 debug로 낮춘 후에 결함의 원인을 쉽게 찾기
		//(2) 에러코드(맛코드)와 같이 오류의 원인을 직관적으로 파악할 수 있는 수단을 설계 단계부터 도입하기
	}
	
	
	@Test
	public void test_잘못된주문테스트() throws Exception {
		int botongCount=0;
		int goppagiCount=0;

		//TODO	잘못된 주문에 대한 처리 로직(부분적 TDD 체험하기)
		
		fail("아직 작성되지 않았습니다");
	}
	
	@Test
	public void testCook_재료양이안맞을때() throws Exception {
		fail("처리로직 생각해 보기");
	}
	
	@Ignore
	public void testCook_재료를볶지않았을때() throws Exception {
		
	}
	
	@Ignore
	public void testCook_필수재료가빠졌을때() throws Exception {
	
	}
	
}
