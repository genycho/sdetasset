package com.sbanjum.person;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.times;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.person.ChoboChef;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ChoboChef.class})
public class ChoboChefMockitoTest {
	
	DanGeun mockDanGeun;
	Yangpa mockYangpa;
	Hobak mockHobak;
	
	ChoboChef choboChef;
	
	@Before
	public void setUp() throws Exception {
		choboChef = new ChoboChef(SBanjumConstants.ROLE_CHOBOCHEF, "테스트용", "백만원");
	}

	@After
	public void tearDown() throws Exception {
	}

	
	@Test
	public void test_기본테스트() throws Exception {
		int inbun = 3;
		List<Vegetable> resultList = choboChef.cook(inbun);
		
		assertNotNull(resultList);
		assertEquals(3, resultList.size());
		
		DanGeun danGeun = null;
		Hobak hobak = null;
		Yangpa yangpa = null;
		
		for(int i=0; i<resultList.size(); i++){
			if("당근".equals(resultList.get(i).getName())){
				danGeun = (DanGeun) resultList.get(i);
			}else if("호박".equals(resultList.get(i).getName())){
				hobak = (Hobak) resultList.get(i);
			}else if("양파".equals(resultList.get(i).getName())){
				yangpa = (Yangpa) resultList.get(i);
			} 
		}
		
		assertNotNull(danGeun);
		assertEquals(0.25*inbun, danGeun.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_SLICED, danGeun.getStatus());

		assertNotNull(hobak);
		assertEquals(0.25*inbun, hobak.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_SLICED, hobak.getStatus());

		assertNotNull(yangpa);
		assertEquals(0.5*inbun, yangpa.getAmount(),0);
		assertEquals(SBanjumConstants.JAERYO_STATUS_SLICED, yangpa.getStatus());
	}

	@Test(expected=CookingException.class)
	public void test_예외확인테스트() throws Exception {
		int inbun = 0;
		
		choboChef.cook(inbun);
		
		fail("기대한 Exception이 발생하지 않았습니다");
	}
	
	
	@Test(expected=CookingException.class)
	public void test_상한당근에대한테스트() throws Exception {
		mockDanGeun = PowerMockito.mock(DanGeun.class);
		PowerMockito.when(mockDanGeun.getStatus()).thenReturn(SBanjumConstants.JAERYO_STATUS_ROTTEN);
		PowerMockito.whenNew(DanGeun.class).withAnyArguments().thenReturn(mockDanGeun);
		
		int inbun = 2;

		choboChef.cook(inbun);
		Mockito.verify(mockDanGeun, atLeastOnce()).getStatus();

		fail("기대한 exception이 발생하지 않았습니다.");
	}
	
	@Test(expected=CookingException.class)
	public void test_상한양파에대한테스트() throws Exception {
		mockYangpa = PowerMockito.mock(Yangpa.class);
		PowerMockito.when(mockYangpa.getStatus()).thenReturn(SBanjumConstants.JAERYO_STATUS_ROTTEN);
		PowerMockito.whenNew(Yangpa.class).withAnyArguments().thenReturn(mockYangpa);
		
		int inbun = 2;

		choboChef.cook(inbun);
		Mockito.verify(mockYangpa).getStatus();

		fail("기대한 exception이 발생하지 않았습니다.");
	}
	
	@Test(expected=CookingException.class)
	public void test_상한호박에대한테스트() throws Exception {
		mockHobak = PowerMockito.mock(Hobak.class);
		PowerMockito.when(mockHobak.getStatus()).thenReturn(SBanjumConstants.JAERYO_STATUS_ROTTEN);
		PowerMockito.whenNew(Hobak.class).withNoArguments().thenReturn(mockHobak);
		
		int inbun = 2;

		choboChef.cook(inbun);
		Mockito.verify(mockHobak, times(1)).getStatus();

		fail("기대한 exception이 발생하지 않았습니다.");
	}
	
	//TODO	(생각하기)만약 부주방장이 매번 요리를 할 때마다 초보주방장이 각 재료들을 알맞은 양으로 썰었는지, 
	// 상한 재료는 아니었는지를 확인 할 수도 있습니다. 하지만 그럴 시간이 없어서 초보 주방장을 믿고 
	//확인 안 하는 경우가 더 현실과 가까울 것입니다. 
	//만약 상한 재료로 요리를 하고 그대로 손님에게 배달이 된다면... 가게는 문을 닫게 될 수도 있습니다.
	// 이런 상세 검증을 수행하는 단위테스트를 수시로 자동으로 수행한다면 그런 위험을 크게 줄일 수 있습니다.

}
