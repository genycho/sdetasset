package com.sbanjum.person;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;

import com.sbanjum.common.CookingException;
import com.sbanjum.common.SBanjumConstants;
import com.sbanjum.jaeryo.Chunjang;
import com.sbanjum.jaeryo.DanGeun;
import com.sbanjum.jaeryo.Gogi;
import com.sbanjum.jaeryo.Hobak;
import com.sbanjum.jaeryo.Jaeryo;
import com.sbanjum.jaeryo.Myun;
import com.sbanjum.jaeryo.Vegetable;
import com.sbanjum.jaeryo.Yangpa;
import com.sbanjum.main.SBanjumKitchen;
import com.sbanjum.person.ChoboChef;
import com.sbanjum.person.SubChef;

@RunWith(MockitoJUnitRunner.class)
public class SubChefMockitoTest {
	private static final int TESTMODE_WRONGNAME = -2;
	private static final int TESTMODE_WRONGCOUNT = -3;
	private static final int TESTMODE_WRONGSTATUS = -4;
	private static final int TESTMODE_BADTASTE = -5;
	private static int TESTMODE_NORMAL = 1;
	private static int TESTMODE_NULL = -1;
	
	SubChef subChef;
	ChoboChef choboChef;

	@Before
	public void setUp() throws Exception {
		subChef = new SubChef(SBanjumConstants.ROLE_SUBCHEF, "테스트용", "삼백만원");
		choboChef = mock(ChoboChef.class);
		SBanjumKitchen.get().setChoboChef(choboChef);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_기본테스트() throws Exception {
		int inbun = 3;
		
		when(choboChef.cook(inbun)).thenReturn(this.mockPrepare(inbun, TESTMODE_NORMAL));

		List<Jaeryo> resultList = subChef.cook(inbun);

		assertNotNull(resultList);
		assertEquals(6, resultList.size());

		Jaeryo jaeryo = null;
		for (int i = 0; i < resultList.size(); i++) {
			if ("당근".equals(resultList.get(i).getName())) {
				jaeryo = (DanGeun) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED,
						jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD, jaeryo.getTaste());
			} else if ("호박".equals(resultList.get(i).getName())) {
				jaeryo = (Hobak) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED,
						jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD, jaeryo.getTaste());
			} else if ("양파".equals(resultList.get(i).getName())) {
				jaeryo = (Yangpa) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED,
						jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD, jaeryo.getTaste());
			} else if ("면".equals(resultList.get(i).getName())) {
				jaeryo = (Myun)resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_BOILED,
						jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD, jaeryo.getTaste());
			} else if ("춘장".equals(resultList.get(i).getName())) {
				jaeryo = (Chunjang) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED,
						jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD, jaeryo.getTaste());
			} else if ("고기".equals(resultList.get(i).getName())) {
				jaeryo = (Gogi) resultList.get(i);

				assertEquals(SBanjumConstants.JAERYO_STATUS_FRIED,
						jaeryo.getStatus());
				assertEquals(SBanjumConstants.TASTE_GOOD, jaeryo.getTaste());
			} else {
				fail("이상한 재료를 요리했습니다 - " + jaeryo.getName());
			}
		}
		// TODO (생각하기)만약 메인주방장이 매번 요리를 할 때마다 부주방장이 각 재료들을 알맞은 양으로,
		// 맛있게 볶았는지를 확인할 수도 있습니다. 또는 시간이 없기 때문에 양만 확인하고 잘 볶았는지는
		// 확인 안 할 수도 있습니다. 실제로도 통합된 개발코드 상에서 모든 예외적인 상황을 다 확인할 수 없습니다.
		// 상세한 검증을 수행하는 단위테스트가 작성되어 있고, 이 단위테스트가 수시로 검증을 수행한다면
		// 이런 위험성은 크게 줄일 수 있습니다.
	}
	
	@Test(expected=CookingException.class)
	public void test_초보주방장이다른재료썰었을때테스트() throws Exception {
		int inbun = 1;
		
		when(choboChef.cook(inbun)).thenReturn(this.mockPrepare(inbun, TESTMODE_WRONGNAME));

		List<Jaeryo> resultList = subChef.cook(inbun);
		fail("기대한 Exception이 발생하지 않았습니다");
	}
	
	@Test(expected=CookingException.class)
	public void test_초보주방장이잘못된양을썰었을때테스트() throws Exception {
		int inbun = 5;
		
		when(choboChef.cook(inbun)).thenReturn(this.mockPrepare(2, TESTMODE_NORMAL));

		List<Jaeryo> resultList = subChef.cook(inbun);
		fail("기대한 Exception이 발생하지 않았습니다");
	}
	
	@Test(expected=CookingException.class)
	public void test_초보주방장이안썰었을때테스트() throws Exception {
		int inbun = 1;
		
		when(choboChef.cook(inbun)).thenReturn(this.mockPrepare(inbun, TESTMODE_WRONGSTATUS));

		List<Jaeryo> resultList = subChef.cook(inbun);
		fail("기대한 Exception이 발생하지 않았습니다");
	}

	@Test(expected=CookingException.class)
	public void test_초보주방장이일을안할때테스트() throws Exception {
		int inbun = 1;
		
		when(choboChef.cook(inbun)).thenReturn(this.mockPrepare(inbun, TESTMODE_NULL));

		List<Jaeryo> resultList = subChef.cook(inbun);

	}
	
	@Test(expected=CookingException.class)
	public void test_초보주방장이재료를덜준비했을때테스트() throws Exception {
		int inbun = 5;
		
		when(choboChef.cook(inbun)).thenReturn(this.mockPrepare(2, TESTMODE_WRONGCOUNT));

		List<Jaeryo> resultList = subChef.cook(inbun);
		fail("기대한 Exception이 발생하지 않았습니다");
	}
	
	@Test(expected=CookingException.class)
	public void test_초보주방장이CookingException을던졌을때() throws Exception {
		int inbun = 5;
		
		//TODO	초보주방장이 요리 관련 Exception을 내며 어떻게 대처해 주어야 할까.
		
		when(choboChef.cook(inbun)).thenThrow(CookingException.class);
		List<Jaeryo> resultList = subChef.cook(inbun);
		fail("기대한 Exception이 발생하지 않았습니다");
	}
	private List<Vegetable> mockPrepare(int inbun, int testMode){
		List<Vegetable> returnList = new ArrayList<Vegetable>();
		Vegetable temp = null;
		if(testMode == TESTMODE_NORMAL){
			/* 당근 임의 더하기 */
			temp = new DanGeun();
			temp.setAmount(inbun*1/4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			returnList.add(temp);
			
			/* 호박 임의 더하기 */
			temp = new Hobak();
			temp.setAmount(inbun*1/4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			returnList.add(temp);
			
			/* 양파 임의 더하기 */
			temp = new Yangpa();
			temp.setAmount(inbun*1/2.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			returnList.add(temp);
		}else if(testMode == TESTMODE_NULL){

			returnList = null;
			
		}else if(testMode == TESTMODE_WRONGNAME){
			/* 당근 임의 더하기 */
			temp = new DanGeun();
			temp.setName("Carrot");
			temp.setAmount(inbun*1/4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			returnList.add(temp);
			
			/* 호박 임의 더하기 */
			temp = new Hobak();
			temp.setName("Pumpkin");
			temp.setAmount(inbun*1/4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			returnList.add(temp);
			
			/* 양파 임의 더하기 */
			temp = new Yangpa();
			temp.setName("Onion");
			temp.setAmount(inbun*1/2.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			returnList.add(temp);
		}else if(testMode == TESTMODE_WRONGCOUNT){
			/* 당근 임의 더하기 */
			temp = new DanGeun();
			temp.setAmount(inbun*1/4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_SLICED);
			returnList.add(temp);
			
		}else if(testMode == TESTMODE_WRONGSTATUS){
			/* 당근 임의 더하기 */
			temp = new DanGeun();
			temp.setAmount(inbun*1/4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_INIT);
			returnList.add(temp);
			
			/* 호박 임의 더하기 */
			temp = new Hobak();
			temp.setAmount(inbun*1/4.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_INIT);
			returnList.add(temp);
			
			/* 양파 임의 더하기 */
			temp = new Yangpa();
			temp.setAmount(inbun*1/2.);
			temp.setStatus(SBanjumConstants.JAERYO_STATUS_FRIED);
			returnList.add(temp);
		}else{
			returnList = null;
			//Not checking, return null
		}
		return returnList;
	}
}
